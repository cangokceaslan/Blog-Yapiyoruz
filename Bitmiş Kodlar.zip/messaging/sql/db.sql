-- phpMyAdmin SQL Dump
-- version 4.8.2
-- https://www.phpmyadmin.net/
--
-- Anamakine: localhost:3306
-- Üretim Zamanı: 01 Haz 2019, 10:40:09
-- Sunucu sürümü: 5.7.21
-- PHP Sürümü: 7.2.7

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";

--
-- Veritabanı: `mesaj`
--

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `messages`
--

CREATE TABLE `messages` (
  `id` int(30) NOT NULL,
  `sender` varchar(40) NOT NULL,
  `receiver` varchar(40) NOT NULL,
  `message` text NOT NULL,
  `date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Tablo döküm verisi `messages`
--

INSERT INTO `messages` (`id`, `sender`, `receiver`, `message`, `date`) VALUES
(52, 'cangokceaslan', 'yazilim', 'Merhaba nasilsin', '2019-06-01'),
(53, 'yazilim', 'cangokceaslan', 'iyiyim loungetayim', '2019-06-01'),
(54, 'cangokceaslan', 'yazilim', '565', '2019-06-01'),
(55, 'yazilim', 'cangokceaslan', '343433', '2019-06-01'),
(56, 'cangokceaslan', 'yazilim', 'Can', '2019-06-01'),
(57, 'yazilim', 'cangokceaslan', 'Message', '2019-06-01'),
(58, 'yazilim', 'cangokceaslan', 'Message', '2019-06-01'),
(59, 'yazilim', 'cangokceaslan', 'Message', '2019-06-01'),
(60, 'yazilim', 'cangokceaslan', 'Deneme', '2019-06-01'),
(61, 'yazilim', 'cangokceaslan', 'Deneme', '2019-06-01'),
(62, 'yazilim', 'cangokceaslan', 'Deneme', '2019-06-01'),
(63, 'yazilim', 'cangokceaslan', 'Deneme', '2019-06-01'),
(64, 'yazilim', 'cangokceaslan', 'Deneme', '2019-06-01'),
(65, 'yazilim', 'cangokceaslan', 'Deneme', '2019-06-01'),
(66, 'yazilim', 'cangokceaslan', 'Deneme', '2019-06-01'),
(67, 'cangokceaslan', 'yazilim', 'Can', '2019-06-01'),
(68, 'cangokceaslan', 'yazilim', 'Can1', '2019-06-01'),
(69, 'cangokceaslan', 'yazilim', 'Can1', '2019-06-01'),
(70, 'cangokceaslan', 'yazilim', 'Can1', '2019-06-01'),
(71, 'cangokceaslan', 'yazilim', 'Can1', '2019-06-01'),
(72, 'cangokceaslan', 'yazilim', 'Can2', '2019-06-01'),
(73, 'cangokceaslan', 'yazilim', 'Can5', '2019-06-01'),
(74, 'cangokceaslan', 'yazilim', 'Can3', '2019-06-01'),
(75, 'yazilim', 'cangokceaslan', 'Deneme', '2019-06-01'),
(76, 'yazilim', 'cangokceaslan', 'XX', '2019-06-01'),
(77, 'yazilim', 'cangokceaslan', 'Can', '2019-06-01'),
(78, 'cangokceaslan', 'mehmet', 'Can', '2019-06-01'),
(79, 'mehmet', 'cangokceaslan', 'Mehmet', '2019-06-01'),
(80, 'cangokceaslan', 'bilal', 'Merhaba', '2019-06-01'),
(81, 'bilal', 'cangokceaslan', 'Merhaba', '2019-06-01'),
(82, 'cangokceaslan', 'bilal', 'Nasilsin', '2019-06-01'),
(83, 'cangokceaslan', 'bilal', 'Nasilsin', '2019-06-01'),
(84, 'cangokceaslan', 'bilal', 'Nasilsin', '2019-06-01'),
(85, 'cangokceaslan', 'bilal', 'Nasilsin', '2019-06-01'),
(86, 'cangokceaslan', 'bilal', 'Nasilsin', '2019-06-01'),
(87, 'cangokceaslan', 'bilal', 'Nasilsin', '2019-06-01'),
(88, 'cangokceaslan', 'bilal', 'Nasilsin', '2019-06-01'),
(89, 'cangokceaslan', 'bilal', 'Nasilsin', '2019-06-01'),
(90, 'cangokceaslan', 'bilal', 'Nasilsin', '2019-06-01'),
(91, 'cangokceaslan', 'bilal', 'Nasilsin', '2019-06-01'),
(92, 'cangokceaslan', 'bilal', 'Nasilsin', '2019-06-01'),
(93, 'cangokceaslan', 'bilal', 'Nasilsin', '2019-06-01'),
(94, 'cangokceaslan', 'bilal', 'Nasilsin', '2019-06-01'),
(95, 'cangokceaslan', 'bilal', 'Nasilsin', '2019-06-01'),
(96, 'cangokceaslan', 'bilal', 'Nasilsin', '2019-06-01'),
(97, 'cangokceaslan', 'bilal', 'Nasilsin', '2019-06-01'),
(98, 'cangokceaslan', 'bilal', 'Nasilsin', '2019-06-01'),
(99, 'cangokceaslan', 'bilal', 'Nasilsin', '2019-06-01'),
(100, 'cangokceaslan', 'bilal', 'Nasilsin', '2019-06-01'),
(101, 'cangokceaslan', 'bilal', 'Nasilsin', '2019-06-01'),
(102, 'cangokceaslan', 'bilal', 'Twitter', '2019-06-01');

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `users`
--

CREATE TABLE `users` (
  `id` int(20) NOT NULL,
  `username` varchar(40) NOT NULL,
  `password` varchar(40) NOT NULL,
  `name` text NOT NULL,
  `surname` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Tablo döküm verisi `users`
--

INSERT INTO `users` (`id`, `username`, `password`, `name`, `surname`) VALUES
(1, 'cangokceaslan', '123456', 'Can', 'Gökçeaslan'),
(2, 'yazilim', '123456', 'Yazılım', 'Öğreniyorum'),
(3, 'mehmet', '123456', 'Mehmet', 'X.'),
(4, 'bilal', '123456', 'Bilal', 'Y.');

--
-- Dökümü yapılmış tablolar için indeksler
--

--
-- Tablo için indeksler `messages`
--
ALTER TABLE `messages`
  ADD PRIMARY KEY (`id`);

--
-- Tablo için indeksler `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`);

--
-- Dökümü yapılmış tablolar için AUTO_INCREMENT değeri
--

--
-- Tablo için AUTO_INCREMENT değeri `messages`
--
ALTER TABLE `messages`
  MODIFY `id` int(30) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=103;

--
-- Tablo için AUTO_INCREMENT değeri `users`
--
ALTER TABLE `users`
  MODIFY `id` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
