<?php 
require("./connect.php");
$id = $_GET["id"];
$sql = "SELECT tblstudents.studentName, tblregistrations.grade, tblregistrations.registrationDate, tblstudents.city FROM tblregistrations INNER JOIN tblstudents ON tblregistrations.studentID = tblstudents.studentID WHERE tblregistrations.courseID = '$id';";
echo "<br/>";
echo "<b>".$sql."</b><br />";
echo "<br/>";
echo "<style>td,th{
    border: 1px solid black !important;
}</style>";
echo "<table>";
echo "<tr>";
echo "<th style='text-align:center;'>Student Name</th>";
echo "<th style='text-align:center;'>Grade</th>";
echo "<th style='text-align:center;'>Registration Date</th>";
echo "<th style='text-align:center;'>City</th>";
echo "</tr>";
$result = mysqli_query($conn,$sql);
while($row = mysqli_fetch_assoc($result)){
    echo "<tr>";
    echo "<td style='text-align:center;'>".$row["studentName"]."</td>";
    echo "<td style='text-align:center;'>".$row["grade"]."</td>";
    echo "<td style='text-align:center;'>".$row["registrationDate"]."</td>";
    echo "<td style='text-align:center;'>".$row["city"]."</td>";
    echo "</tr>";
}
echo "</table>";
?>