<?php 
require('./connect.php');
echo "<b>a)</b><br/>";
$sql = "SELECT courseName, courseID FROM tblcourses WHERE 1";
echo "<br/>";
echo "<b>".$sql."</b><br />";
echo "<br/>";
echo "<br/>";
$result = mysqli_query($conn,$sql);
echo "<ul style='list-style:none;'>";
echo "<style> li{border:2px solid black; max-width: 40%;padding:20px;font-size:20px;} </style>";
while($row = mysqli_fetch_assoc($result)){
    echo "<li><a href='./detay.php?id=".$row['courseID']."'>".$row['courseName']."</li>";
}
echo "</ul>";
?>