<?php
require('connect.php');
echo "<b>a)</b> <br/>";
$sql = "SELECT instructorName, instructorID FROM tblinstructor WHERE 1 ORDER BY instructorName ASC";
echo "<br/>";
echo "<b>".$sql."</b><br />";
echo "<br/>";
echo "<b>b)</b> <br/>";
echo "<br/>";
$result = mysqli_query($conn, $sql);
while($row = mysqli_fetch_assoc($result)){
    echo $row["instructorName"].",".$row["instructorID"]."<br/>";
}
echo "<br/>";
echo "<b>c)</b> <br/>";
echo "<br/>";
echo "<select>";
$result = mysqli_query($conn, $sql);
while($row1 = mysqli_fetch_assoc($result)){
        echo "<option value='".$row1["instructorID"]."'>".$row1["instructorName"]."</option>";
}
echo "</select>";
echo "<br />";
echo "<br/>";
echo "<b>d) & e)</b> <br/>";
echo "<br/>";
$result = mysqli_query($conn, $sql);
echo "<form id='form' method='GET' action='./another.php'>";
$str = '"form"';
echo "<select name='instructorID' onchange='document.getElementById(".$str.").submit();'>";
echo "<option>Select Instructor</option>";
while($row2 = mysqli_fetch_assoc($result)){
        echo "<option value='".$row2["instructorID"]."'>".$row2["instructorName"]."</option>";
}
echo "</select>";
echo "<br />";
echo "<br/>";
echo "<button>Get Details</button>";
echo "</form>";
?>