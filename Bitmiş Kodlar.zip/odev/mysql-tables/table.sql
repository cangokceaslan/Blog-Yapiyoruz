-- phpMyAdmin SQL Dump
-- version 4.8.2
-- https://www.phpmyadmin.net/
--
-- Anamakine: localhost:3306
-- Üretim Zamanı: 24 May 2019, 22:04:51
-- Sunucu sürümü: 5.7.21
-- PHP Sürümü: 7.2.7

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";

--
-- Veritabanı: `project`
--

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `tblcourses`
--

CREATE TABLE `tblcourses` (
  `courseID` int(20) NOT NULL,
  `courseName` text NOT NULL,
  `credits` int(4) NOT NULL,
  `startDate` date NOT NULL,
  `instructorID` int(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Tablo döküm verisi `tblcourses`
--

INSERT INTO `tblcourses` (`courseID`, `courseName`, `credits`, `startDate`, `instructorID`) VALUES
(1, 'Course 1', 3, '2019-02-07', 1),
(2, 'Course 2', 4, '2019-02-07', 2),
(3, 'Course 3', 4, '2019-02-07', 1),
(4, 'Course 4', 3, '2019-02-07', 1),
(5, 'Course 5', 3, '2019-02-07', 1);

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `tblinstructor`
--

CREATE TABLE `tblinstructor` (
  `instructorID` int(20) NOT NULL,
  `instructorName` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Tablo döküm verisi `tblinstructor`
--

INSERT INTO `tblinstructor` (`instructorID`, `instructorName`) VALUES
(1, 'Mehmet Bey'),
(2, 'Arzu Hanım'),
(3, 'Can Bey'),
(4, 'Deniz Bey');

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `tblregistrations`
--

CREATE TABLE `tblregistrations` (
  `regID` int(20) NOT NULL,
  `courseID` int(20) NOT NULL,
  `studentID` int(20) NOT NULL,
  `registrationDate` date NOT NULL,
  `grade` decimal(10,0) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Tablo döküm verisi `tblregistrations`
--

INSERT INTO `tblregistrations` (`regID`, `courseID`, `studentID`, `registrationDate`, `grade`) VALUES
(1, 1, 1, '2019-01-23', '100'),
(2, 5, 1, '2019-02-08', '80'),
(3, 1, 3, '2019-02-07', '100'),
(4, 4, 4, '2019-01-22', '99'),
(5, 2, 1, '2019-01-21', '99'),
(6, 5, 3, '2019-02-23', '99'),
(7, 3, 3, '2019-01-12', '99'),
(8, 3, 4, '2019-01-12', '80');

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `tblstudents`
--

CREATE TABLE `tblstudents` (
  `studentID` int(20) NOT NULL,
  `studentName` text NOT NULL,
  `city` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Tablo döküm verisi `tblstudents`
--

INSERT INTO `tblstudents` (`studentID`, `studentName`, `city`) VALUES
(1, 'Can', 'Istanbul'),
(2, 'Bora', 'İstanbul'),
(3, 'Kamil', 'Istanbul'),
(4, 'Deniz', 'Istanbul');

--
-- Dökümü yapılmış tablolar için indeksler
--

--
-- Tablo için indeksler `tblcourses`
--
ALTER TABLE `tblcourses`
  ADD PRIMARY KEY (`courseID`);

--
-- Tablo için indeksler `tblinstructor`
--
ALTER TABLE `tblinstructor`
  ADD PRIMARY KEY (`instructorID`);

--
-- Tablo için indeksler `tblregistrations`
--
ALTER TABLE `tblregistrations`
  ADD PRIMARY KEY (`regID`);

--
-- Tablo için indeksler `tblstudents`
--
ALTER TABLE `tblstudents`
  ADD PRIMARY KEY (`studentID`);

--
-- Dökümü yapılmış tablolar için AUTO_INCREMENT değeri
--

--
-- Tablo için AUTO_INCREMENT değeri `tblcourses`
--
ALTER TABLE `tblcourses`
  MODIFY `courseID` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- Tablo için AUTO_INCREMENT değeri `tblinstructor`
--
ALTER TABLE `tblinstructor`
  MODIFY `instructorID` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- Tablo için AUTO_INCREMENT değeri `tblregistrations`
--
ALTER TABLE `tblregistrations`
  MODIFY `regID` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- Tablo için AUTO_INCREMENT değeri `tblstudents`
--
ALTER TABLE `tblstudents`
  MODIFY `studentID` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
