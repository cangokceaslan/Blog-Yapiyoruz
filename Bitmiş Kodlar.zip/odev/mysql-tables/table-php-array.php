<?php
/**
 * Export to PHP Array plugin for PHPMyAdmin
 * @version 4.8.2
 */

/**
 * Database `project`
 */

/* `project`.`tblcourses` */
$tblcourses = array(
  array('courseID' => '1','courseName' => 'Course 1','credits' => '3','startDate' => '2019-02-07','instructorID' => '1'),
  array('courseID' => '2','courseName' => 'Course 2','credits' => '4','startDate' => '2019-02-07','instructorID' => '2'),
  array('courseID' => '3','courseName' => 'Course 3','credits' => '4','startDate' => '2019-02-07','instructorID' => '1'),
  array('courseID' => '4','courseName' => 'Course 4','credits' => '3','startDate' => '2019-02-07','instructorID' => '1'),
  array('courseID' => '5','courseName' => 'Course 5','credits' => '3','startDate' => '2019-02-07','instructorID' => '1')
);

/* `project`.`tblinstructor` */
$tblinstructor = array(
  array('instructorID' => '1','instructorName' => 'Mehmet Bey'),
  array('instructorID' => '2','instructorName' => 'Arzu Hanım'),
  array('instructorID' => '3','instructorName' => 'Can Bey'),
  array('instructorID' => '4','instructorName' => 'Deniz Bey')
);

/* `project`.`tblregistrations` */
$tblregistrations = array(
  array('regID' => '1','courseID' => '1','studentID' => '1','registrationDate' => '2019-01-23','grade' => '100'),
  array('regID' => '2','courseID' => '5','studentID' => '1','registrationDate' => '2019-02-08','grade' => '80'),
  array('regID' => '3','courseID' => '1','studentID' => '3','registrationDate' => '2019-02-07','grade' => '100'),
  array('regID' => '4','courseID' => '4','studentID' => '4','registrationDate' => '2019-01-22','grade' => '99'),
  array('regID' => '5','courseID' => '2','studentID' => '1','registrationDate' => '2019-01-21','grade' => '99'),
  array('regID' => '6','courseID' => '5','studentID' => '3','registrationDate' => '2019-02-23','grade' => '99'),
  array('regID' => '7','courseID' => '3','studentID' => '3','registrationDate' => '2019-01-12','grade' => '99'),
  array('regID' => '8','courseID' => '3','studentID' => '4','registrationDate' => '2019-01-12','grade' => '80')
);

/* `project`.`tblstudents` */
$tblstudents = array(
  array('studentID' => '1','studentName' => 'Can','city' => 'Istanbul'),
  array('studentID' => '2','studentName' => 'Bora','city' => 'İstanbul'),
  array('studentID' => '3','studentName' => 'Kamil','city' => 'Istanbul'),
  array('studentID' => '4','studentName' => 'Deniz','city' => 'Istanbul')
);
