<?php 
require("./connect.php");
echo "<b>a)</b><br/>";
$sql = "SELECT AVG(D.AVERAGE / D.AVGDIVIDE) AS avg FROM (SELECT SUM(tblcourses.credits * tblregistrations.grade) AS AVERAGE,SUM(tblcourses.credits) AS AVGDIVIDE FROM tblregistrations INNER JOIN tblcourses ON tblregistrations.courseID = tblregistrations.courseID WHERE 1 GROUP BY tblcourses.courseID,tblregistrations.courseID ) D WHERE 1;";
echo "<br/>";
echo "<b>".$sql."</b><br />";
echo "<br/>";
echo "<style>td,th{
    border: 1px solid black !important;
}</style>";
$result = mysqli_query($conn,$sql);
echo "Weighted Average of All Students: ";
while($row = mysqli_fetch_assoc($result)){
    echo $row["avg"];
}
echo "<br />";
echo "<b>b)</b><br/>";
$sql1 = "SELECT AVG(D.AVERAGE / D.AVGDIVIDE) AS avg FROM (SELECT SUM(tblcourses.credits * tblregistrations.grade) AS AVERAGE,SUM(tblcourses.credits) AS AVGDIVIDE FROM tblregistrations INNER JOIN tblcourses ON tblregistrations.courseID = tblregistrations.courseID WHERE tblregistrations.registrationDate <= tblcourses.startDate GROUP BY tblcourses.courseID,tblregistrations.courseID ) D WHERE 1;";
echo "<br/>";
echo "<b>".$sql1."</b><br />";
echo "<br/>";
echo "<style>td,th{
    border: 1px solid black !important;
}</style>";
$result1 = mysqli_query($conn,$sql1);
echo "Weighted Average of Registration Date Excluded Students: ";
while($row1 = mysqli_fetch_assoc($result1)){
    echo $row1["avg"];
}

?>