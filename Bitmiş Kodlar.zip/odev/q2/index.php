<?php 
require('connect.php');
echo "<b>a)</b><br/>";
$sql = "SELECT * FROM tblcourses JOIN tblinstructor ON tblcourses.instructorID = tblinstructor.instructorID WHERE 1;";
echo "<br/>";
echo "<b>".$sql."</b>";
echo "<br/>";
echo "<br/>";
$result = mysqli_query($conn,$sql);
echo "<table>";
echo "<tr>";
echo "<th style='text-align:center;'>Instructor Name</th>";
echo "<th style='text-align:center;'>Courses</th>";
echo "</tr>";
while($row = mysqli_fetch_assoc($result)){
    echo "<tr>";
    echo "<td style='text-align:center;'>".$row["instructorName"]."</td>";
    echo "<td style='text-align:center;'>".$row["courseName"]."</td>";
    echo "</tr>";
}
echo "</table>";
echo "<b>b)</b><br/>";
$sql1 = "SELECT tblinstructor.instructorName, COUNT(distinct tblregistrations.regID) AS count1, COUNT(distinct tblcourses.courseID) AS count2 FROM tblinstructor INNER JOIN tblcourses ON tblcourses.instructorID = tblinstructor.instructorID INNER JOIN tblregistrations ON tblcourses.courseID = tblregistrations.courseID WHERE 1 GROUP BY tblinstructor.instructorID,tblcourses.instructorID;";
echo "<br/>";
echo "<b>".$sql1."</b><br />";
echo "<br/>";
$result1 = mysqli_query($conn,$sql1);
echo "<style>td,th{
    border: 1px solid black !important;
}</style>";
echo "<table>";
echo "<tr>";
echo "<th style='text-align:center;'>Instructor Name</th>";
echo "<th style='text-align:center;'>Total Students</th>";
echo "<th style='text-align:center;'>Total Courses</th>";
echo "</tr>";
while($row = mysqli_fetch_assoc($result1)){
    echo "<tr>";
    echo "<td style='text-align:center;'>".$row["instructorName"]."</td>";
    echo "<td style='text-align:center;'>".$row["count1"]."</td>";
    echo "<td style='text-align:center;'>".$row["count2"]."</td>";
    echo "</tr>";
}
echo "</table>";
echo "<b>c)</b><br/>";
echo "<br/>";
$sql2 = "SELECT tblcourses.courseName, COUNT(DISTINCT tblregistrations.regID) AS nstudents, AVG(DISTINCT tblregistrations.grade) AS average FROM tblcourses INNER JOIN tblregistrations ON tblcourses.courseID = tblregistrations.courseID WHERE tblregistrations.courseID = tblcourses.courseID GROUP BY tblregistrations.courseID;";
echo "<b>".$sql2."</b>";
echo "<br/>";
echo "<br/>";
echo "<table>";
echo "<tr>";
echo "<th style='text-align:center;'>Instructor Name</th>";
echo "<th style='text-align:center;'>Total Students</th>";
echo "<th style='text-align:center;'>Total Courses</th>";
echo "</tr>";
$result2 = mysqli_query($conn,$sql2);
while($row = mysqli_fetch_assoc($result2)){
    echo "<tr>";
    echo "<td style='text-align:center;'>".$row["courseName"]."</td>";
    echo "<td style='text-align:center;'>".$row["nstudents"]."</td>";
    echo "<td style='text-align:center;'>".$row["average"]."</td>";
    echo "</tr>";
}
?>
