<?php 
session_name("admin");
session_start();
if($_GET["logout"] == 1){
  session_destroy();
  header("Location: http://localhost/panel/login.php");
}
if($_SESSION["email"] == "cangokceaslan@gmail.com" && $_SESSION["password"] == "123456"){

}else{
  header("Location: http://localhost/panel/login.php");
}
define('HOST','localhost');
define('USER','root');
define('PASS','root');
define('DB','blog');
$conn = mysqli_connect(HOST,USER,PASS,DB) or die("No connection");
function update($conn,$id, $title, $description, $post, $url, $author, $image){
  $sql = 'UPDATE blog SET title="'.$title.'", description="'.$description.'", post="'.$post.'", url="'.$url.'", author="'.$author.'", image="'.$image.'" WHERE id='.$id;
  mysqli_query($conn,$sql);

}
$image = $_POST["old_image"];
if(isset($_POST["id"]) && isset($_POST["title"]) && isset($_POST["description"]) && isset($_POST["post"]) && isset($_POST["url"]) &&  isset($_POST["author"]) && isset($_FILES["image"]["tmp_name"]) && isset($_POST["old_image"])){
    $type = explode(".",$_FILES["image"]["name"])[1];
    $name = md5($_FILES["image"]["name"]).".".$type;
    $bool = move_uploaded_file($_FILES["image"]["tmp_name"],"../img/".$name);
    if($bool == true){
      unlink("../".$image);
      $image = "../img/".$name;
    }
    update($conn,$_POST["id"],$_POST["title"],$_POST["description"],$_POST["post"],$_POST["url"],$_POST["author"],$image);
}
function getPostsById($conn,$id){
  $sql = "SELECT * FROM blog WHERE id=".$id." LIMIT 1;";
  $result = mysqli_query($conn,$sql);
  $counter = 0;
  while($row = mysqli_fetch_assoc($result)){
      $data = $row;
    }
    return $data;
  }
function getPosts($conn){
    $sql = "SELECT * FROM blog WHERE 1";
    $result = mysqli_query($conn,$sql);
    $counter = 0;
    while($row = mysqli_fetch_assoc($result)){
        $counter++;
        if($counter % 2 == 1){
            $oddeven = "odd";
        }else{
            $oddeven = "even";
        }
         echo "<tr role='row' class='".$oddeven."'>";
         echo "<td>".$row["id"]."</td>";
         echo "<td><a href=./index.php?post=".$row["id"]." class='btn btn-primary'>Düzenle</a></td>";
         echo "<td>".$row["title"]."</td>";
         echo "<td>".$row["description"]."</td>";
         echo "<td> http://domain.com/post/".$row["url"]."</td>";
         echo "<td>".$row["author"]."</td>";
         echo "<td>".$row["date"]."</td>";
         echo "<td><img src='http://localhost/".$row["image"]."' width='100px' alt='' /></td>";
        echo "</tr>";
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<base href="http://localhost/panel/" />
<head>

  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <meta name="author" content="">

  <title>SB Admin 2 - Dashboard</title>

  <!-- Custom fonts for this template-->
  <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
  <link href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i" rel="stylesheet">

  <!-- Custom styles for this template-->
  <link href="css/sb-admin-2.min.css" rel="stylesheet">
    <style>
        td{
            border: 2px solid lightgray;
            text-overflow:ellipses;
            overflow:hidden;
        }
        </style>
</head>

<body id="page-top" style="padding-top:20px;">

  
        <!-- Begin Page Content -->
        <div class="container-fluid">

          <!-- Page Heading -->
          <div class="d-sm-flex align-items-center justify-content-between mb-4">
            <h1 class="h3 mb-0 text-gray-800">Dashboard</h1>
            <a href="./index.php?logout=1" class="d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm"><i class="fas fa-download fa-sm fa-sign-out-alt"></i> Çıkış Yap</a>
          </div>

          <!-- Content Row -->
          <div class="row">

            <!-- Earnings (Monthly) Card Example -->
            <div class="col-xl-3 col-md-6 mb-4">
              <div class="card border-left-primary shadow h-100 py-2">
                <div class="card-body">
                  <div class="row no-gutters align-items-center">
                    <div class="col mr-2">
                      <div class="text-xs font-weight-bold text-primary text-uppercase mb-1">Earnings (Monthly)</div>
                      <div class="h5 mb-0 font-weight-bold text-gray-800">$40,000</div>
                    </div>
                    <div class="col-auto">
                      <i class="fas fa-calendar fa-2x text-gray-300"></i>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            <!-- Earnings (Monthly) Card Example -->
            <div class="col-xl-3 col-md-6 mb-4">
              <div class="card border-left-success shadow h-100 py-2">
                <div class="card-body">
                  <div class="row no-gutters align-items-center">
                    <div class="col mr-2">
                      <div class="text-xs font-weight-bold text-success text-uppercase mb-1">Earnings (Annual)</div>
                      <div class="h5 mb-0 font-weight-bold text-gray-800">$215,000</div>
                    </div>
                    <div class="col-auto">
                      <i class="fas fa-dollar-sign fa-2x text-gray-300"></i>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            <!-- Earnings (Monthly) Card Example -->
            <div class="col-xl-3 col-md-6 mb-4">
              <div class="card border-left-info shadow h-100 py-2">
                <div class="card-body">
                  <div class="row no-gutters align-items-center">
                    <div class="col mr-2">
                      <div class="text-xs font-weight-bold text-info text-uppercase mb-1">Tasks</div>
                      <div class="row no-gutters align-items-center">
                        <div class="col-auto">
                          <div class="h5 mb-0 mr-3 font-weight-bold text-gray-800">50%</div>
                        </div>
                        <div class="col">
                          <div class="progress progress-sm mr-2">
                            <div class="progress-bar bg-info" role="progressbar" style="width: 50%" aria-valuenow="50" aria-valuemin="0" aria-valuemax="100"></div>
                          </div>
                        </div>
                      </div>
                    </div>
                    <div class="col-auto">
                      <i class="fas fa-clipboard-list fa-2x text-gray-300"></i>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            <!-- Pending Requests Card Example -->
            <div class="col-xl-3 col-md-6 mb-4">
              <div class="card border-left-warning shadow h-100 py-2">
                <div class="card-body">
                  <div class="row no-gutters align-items-center">
                    <div class="col mr-2">
                      <div class="text-xs font-weight-bold text-warning text-uppercase mb-1">Pending Requests</div>
                      <div class="h5 mb-0 font-weight-bold text-gray-800">18</div>
                    </div>
                    <div class="col-auto">
                      <i class="fas fa-comments fa-2x text-gray-300"></i>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>

          <!-- Content Row -->

          <div class="row">

            <!-- Area Chart -->
            <div class="col-xl-12 col-lg-12">
              <div class="card shadow mb-4">
                <!-- Card Header - Dropdown -->
                <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                  <h6 class="m-0 font-weight-bold text-primary">Earnings Overview</h6>
                </div>
                <!-- Card Body -->
                <div class="card-body">
                  <table style="text-align:center;width:100%;overflow:scroll !important;" >
                      <thead style="padding:5px;">
                          <th>Id</th>
                          <th>Yazıyı Düzenle</th>
                          <th>Başlık</th>
                          <th>Açıklama</th>
                          <th>Url</th>
                          <th>Yazar</th>
                          <th>Tarih</th>
                          <th>Resim</th>
                    </thead>
                    <tbody>
                    <?php getPosts($conn); ?>
                    </tbody>
                    </table>
                </div>
              </div>
            </div>

            <!-- Pie Chart -->
            <?PHP if($_GET["post"] != null){
              $dataPost = getPostsById($conn,$_GET["post"]);
            } ?>
            <div class="col-xl-12 col-lg-12"  style="<?php if(! isset($_GET["post"])){ echo "display:none"; }?>">
              <div class="card shadow mb-4">
                <!-- Card Header - Dropdown -->
                <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                  <h6 class="m-0 font-weight-bold text-primary">Revenue Sources</h6>
                </div>
                <!-- Card Body -->
                <div class="card-body">
                <style>
                .inputduzenle{
                  display:block;
                  margin: 3px 2px 3px 2px;
                  width:100%;
                  border:2px solid green;
                }
                .inputlabel{
                  color:black;
                  font-weight:bold;
                }
                </style>
                <form id="duzenle" enctype="multipart/form-data" method="POST">
                  <input class="inputduzenle"  type="hidden" id="id" name="id" value="<?php echo $dataPost["id"]  ?>" />
                  <label class="inputlabel" for="title">Başlık:</label>
                  <input class="inputduzenle"  type="text" id="title" name="title" value="<?php echo $dataPost["title"]  ?>" />
                  <label class="inputlabel" for="description">Açıklama:</label>
                  <input class="inputduzenle" type="text" id="description" name="description" value="<?php echo $dataPost["description"]  ?>" />
                  <label class="inputlabel" for="duzenle">Post:</label>
                  <textarea rows="10" class="inputduzenle" id="duzenle" name="post"><?php echo $dataPost["post"]  ?></textarea>
                  <label class="inputlabel" for="url">Url:</label>
                  <input class="inputduzenle" type="text" id="url" name="url" value="<?php echo $dataPost["url"]  ?>" />
                  <label class="inputlabel" for="authot">Yazar:</label>
                  <input class="inputduzenle" id="author" type="text" name="author" value="<?php echo $dataPost["author"]  ?>" />
                  <label class="inputlabel" for="image">Resim:</label>
                  <input class="inputduzenle" id="image" type="file" name="image" />
                  <input type="hidden" name="old_image" value="<?php echo $dataPost["image"]; ?>" />
                  <img src="../<?php echo $dataPost["image"]; ?>" height="auto" width="100%" alt="deneme">
                  <button>Gönder</button>
                  </form>

              </div>
            </div>
          </div>

          <!-- Content Row -->
          <div class="row">

            <!-- Content Column -->
            <div class="col-lg-6 mb-4">

              <!-- Project Card Example -->
             
        <!-- /.container-fluid -->

      </div>
      <!-- End of Main Content -->

      <!-- Footer -->
      <footer class="sticky-footer bg-white">
        <div class="container my-auto">
          <div class="copyright text-center my-auto">
            <span>Copyright &copy; Your Website 2019</span>
          </div>
        </div>
      </footer>
      <!-- End of Footer -->

    </div>
    <!-- End of Content Wrapper -->

  </div>
  <!-- End of Page Wrapper -->

  <!-- Scroll to Top Button-->
  <a class="scroll-to-top rounded" href="#page-top">
    <i class="fas fa-angle-up"></i>
  </a>

  <!-- Logout Modal-->
  <div class="modal fade" id="logoutModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="exampleModalLabel">Ready to Leave?</h5>
          <button class="close" type="button" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">×</span>
          </button>
        </div>
        <div class="modal-body">Select "Logout" below if you are ready to end your current session.</div>
        <div class="modal-footer">
          <button class="btn btn-secondary" type="button" data-dismiss="modal">Cancel</button>
          <a class="btn btn-primary" href="login.html">Logout</a>
        </div>
      </div>
    </div>
  </div>

  <!-- Bootstrap core JavaScript-->
  <script src="vendor/jquery/jquery.min.js"></script>
  <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

  <!-- Core plugin JavaScript-->
  <script src="vendor/jquery-easing/jquery.easing.min.js"></script>

  <!-- Custom scripts for all pages-->
  <script src="js/sb-admin-2.min.js"></script>

  <!-- Page level plugins -->
  <script src="vendor/chart.js/Chart.min.js"></script>

  <!-- Page level custom scripts -->
  <script src="js/demo/chart-area-demo.js"></script>
  <script src="js/demo/chart-pie-demo.js"></script>

</body>

</html>
